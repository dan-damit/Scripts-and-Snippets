# Fixing Queries

**Date:** 2026-6-7 **Tags:** sql, queries, performance

## Fixing a 15million row table

This one was a doozy. We have an application that is absolutely mission critical
for our business to run. And it's been slowly getting slower and slower over
the last 6 months since I've started. I fixed the unresponsive front end
webserver issues, and it was fine for a few hours with 0 issues. But then out of
no where, the application would just stop responding again.. 

I jumped on the server and found that PostgreSQL was running at 100% CPU. I ran
a query to see what was going on, and found that there was a query running that
was taking up all the resources. It was a simple SELECT statement that was
running against a table with 15 million rows. I looked at the query and it was
doing a full table scan, which is why it was taking so long. I added an index to
the table, and the query ran in seconds instead of minutes.

So now between the front end responsiveness and the database performance, the
application is running smoothly again. It's amazing how much of a difference a
little bit of optimization can make.

The best part is that I was able to fix this without any downtime. I was able to
add the index while the application was still running, and it didn't cause any
issues. It's always a relief when you can fix something without having to take
the system down.

And over the past weekend, I came up with a plan to add some reliability to the
system as well. I want to use NSSM to make the application run as a service, so
that if it crashes, it will automatically restart. I also want to set up some
monitoring and alerting, so that if the application does crash, I'll be notified
immediately.

### dan

---

# TechToolbox is public!

**Date:** 2026-6-15 **Tags:** techtoolbox, public, open source

## It's available on PSGallery as we speak!

I'm so excited to announce that TechToolbox is now public! It's available on
PSGallery as we speak, and I can't wait for everyone to start using it.So far it
has almost 80 downloads in a few days.

TechToolbox is a collection of PowerShell scripts and modules that I've been
working on for the past few years. It's designed to help IT professionals and
system administrators with their daily tasks, and to make their lives easier.

[You can check it out here!](https://www.powershellgallery.com/packages/TechToolbox)
[And the GitHub repo is here!](https://github.com/dan-damit/TechToolbox)

I'm really proud of this project, and I hope that it will be useful to a lot of
people. I'm also looking forward to getting feedback and contributions from the
community, so if you have any ideas or suggestions, please don't hesitate to
reach out!

### dan