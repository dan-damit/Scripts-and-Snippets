# Creating Dashboards

**Date:** 2026-04-13 **Tags:** sql, queries, applications

## Learning Epicor

The focus in the past few weeks at work has been learning Kinetics, Epicor's
SaaS solution for ERP. After several sessions with the bossman showing me the
ropes on what baked in apps/baqs that we customized, I was able to fix a few
bugs that popped up with a few dashboards after the upgrade from on-prem to
SaaS. Earning my keep so far!

It is the direction I definitely wanted to be going with the new enviornment.
ERP support will eventually give way to BI analyst role. :)

### dan

---

# Lots of stuff to do...

**Date:** 2026-04-26 **Tags:** scripting, erp, sql

## There have been some very good challenges

I love this new role. It is right in my wheelhouse of what I wanted to do in IT
when I started this career change in 2012; it's just taken a little longer than
I'd originally thought to get here. The challenges are there (I doubt I'll ever
get bored). I feel the value I am brining to the team is farily compensated. The
team is a tight knit group with high expectiations and accountability. Not much
more I could ask for!

And the boss wants me to make a closed version of my Toolbox tailored
specifically for our environment. Sometihng the team can use if they feel
comfortable enough with PowerShell to help speed up some of the more repetitive
tasks. The main overarching goal is to minimize variance in specific workflows
by automating the repetitive stuff like employee onboarding and offboarding.

SQL and Kinetic (and its C# backend function libraries) have been the real
challenge. 3 out of 5 days every week I actually need the weekend to recharge
and unplug as best as I can. I almost always end up doing some level of
scripting or reading on PowerShell. I feel I FINALLY have an organization that I
can spend more than 5 years with and feel like I didn't have to settle for
anything less than what I wanted.

Onward and upward!

### dan
