# Fixing Queries

**Date:** 2026-6-7 **Tags:** sql, queries, performance

## Fixing a 15million row table

This one was a doozy. We have an application that is absolutely mission critical
for our business to run. And it's been slowly getting slower and slower over
the last 6 months since I've started. I fixed the unresponsive front end
webserver issues, and it was fine for a few hours with 0 issues. But then out of
no where, the application would just stop responding again.. 

I jumped on the server and found that PostgreSQL was running at 100% CPU. I ran
a query to see what was going on, and found that there was a query running that
was taking up all the resources. It was a simple SELECT statement that was
running against a table with 15 million rows. I looked at the query and it was
doing a full table scan, which is why it was taking so long. I added an index to
the table, and the query ran in seconds instead of minutes.

So now between the front end responsiveness and the database performance, the
application is running smoothly again. It's amazing how much of a difference a
little bit of optimization can make.

The best part is that I was able to fix this without any downtime. I was able to
add the index while the application was still running, and it didn't cause any
issues. It's always a relief when you can fix something without having to take
the system down.

And over the past weekend, I came up with a plan to add some reliability to the
system as well. I want to use NSSM to make the application run as a service, so
that if it crashes, it will automatically restart. I also want to set up some
monitoring and alerting, so that if the application does crash, I'll be notified
immediately.

### dan
