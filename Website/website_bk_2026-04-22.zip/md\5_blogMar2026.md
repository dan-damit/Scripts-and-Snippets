# Upgrading to RB5009

**Date:** 2026-3-5 **Tags:** mikrotik, networking

## Was maxing out the hEXs

I realized after changing up the way my GeoIP filtering works, that it loads the
address subnets for countries into the firewall's memory. After I hardened it to
be a GeoIP whitelist, the hEXs memory was almost 100% usage... and the CPU was
constantly between 35-50% or so. 

### Enter the RB5009

It has quaduple the memory and something like 100x more storage onboard, makes
easy work of my firewall rules. An added bonus is, my TDS fiber modem connects
to ether1 at 2.5G. I only have a gig connection, but there is room to expand in
the future now.

It only took like an hour to export the stuff I wanted to keep like CAPsMAN
settings, firewall settings, and the task scheduler that keeps the GeoIP lists
up to date. the rest I just built out - like the DHCP and DNS stuff, the IoT
VLAN, and things like that. 

It was plug and play when I got the config setup in the RB5009. Downtime was
literally 15 seconds, and the cAP AC units didn't complain one bit about
swapping controllers.

I love MikroTik - basically poor man's CISCO.

### dan

---

# NVIDIA driver issues...

**Date:** 2026-3-11 **Tags:** drivers, crashing, bios

## Recent drivers causing chaos

I think the recent driver updates from NVIDIA brought back (unintentionally I
can imagine) the dang black screen driver crashes. BlueScreenView pointed to the
NVIDIA drivers every time. I ended up using the DDU and some BIOS tweaks to turn
off all active power and performance states. All ASPM "features" have been
disabled in the BIOS. I also forced Max Performance Mode for the power mode in
the NVIDIA control panel. I rolled back to the last driver version that didn't
blow up my system:

[Link here to the NVIDIA 591.74 drivers](https://www.nvidia.com/en-us/drivers/)

Did the manual search for past versions and downloaded 591.74 for my 5080.

### dan

---

# DoH changes with Cloudflared

**Date:** 2026-3-21 **Tags:** networking, dns, pihole

## Cloudflare changed the Cloudflared with DoH

They deprecated DoH within their Cloudflared package for pihole, but they did
not get rid of DNS over HTTPS completely. I just had to switch gears on how it
works in PiHole. And I got the added bonus of transferring my domain registrar
from GoDaddy to Cloudflare also so I could play with their new Tunnel feature
with PiHole. But before I get into that, I had to install dnscrypt-proxy
separate from Cloudflared and config it to run just like Cloudflared used to on
the PiHole for DOH.

This site was HUGE help:

[PiHole DoH Docs](https://docs.pi-hole.net/guides/dns/dnscrypt-proxy/)

Basically does the same thing but separated out from Cloudflared now. They are
two different things now. This project today had the added bonus of finding and
fixing a couple of DNS loops I didn't know I had within my PiHole configs.

It's nice to see this too, not that GoDaddy was bad... I just like Cloudflare.

a:thedamits.com : 'Your DNS hosting provider is "Cloudflare"'

```bash
dan@pihole:/opt/dnscrypt-proxy $ dig @127.0.0.1 -p 5053 cloudflare.com

; <<>> DiG 9.18.44-1~deb12u1-Debian <<>> @127.0.0.1 -p 5053 cloudflare.com
; (1 server found)
;; global options: +cmd
;; Got answer:
;; ->>HEADER<<- opcode: QUERY, status: NOERROR, id: 40196
;; flags: qr rd ra ad; QUERY: 1, ANSWER: 2, AUTHORITY: 0, ADDITIONAL: 1
;; OPT PSEUDOSECTION:
; EDNS: version: 0, flags:; udp: 1232
;; QUESTION SECTION:
;cloudflare.com.                        IN      A
;; ANSWER SECTION:
cloudflare.com.         2400    IN      A       104.16.132.229
cloudflare.com.         2400    IN      A       104.16.133.229
;; Query time: 67 msec
;; SERVER: 127.0.0.1#5053(127.0.0.1) (UDP)
;; WHEN: Sat Mar 21 15:36:15 CDT 2026
;; MSG SIZE  rcvd: 75
```

Those flags in the dig response are beautiful...

### dan
