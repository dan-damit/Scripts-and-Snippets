# A new personal project

**Date:** 2026-7-4 **Tags:** coding, development, shell

## I had an idea...

I want to create a new shell experience that essentially replaces the
explorer.exe. I think it would be a fun project to work on, and I have some
ideas for how to make it integrated with AI, too! At least, that is the idea...
lets see if it actually works out.

The overall architecture will be:
```markdown
- C# WinUI 3 Frontend (Shell Overlay UI)
- C# Backend (Shell Logic, File System Access, etc.)
- AI Integration (local LLM for code generation, search, and other tasks)
- And a panel for my TechToolbox
```

So far that is the initial outline. I want to create a OneNote to keep track of
all the ideas and features I want to implement. I will also create a GitHub
repository to track the code and issues. I think this project will be a great
way to learn more about Windows development, AI integration, and creating a
unique user experience.

### dan

---

# A template system for the AI Agent

**Date:** 2026-7-20 **Tags:** ai, development

## The templates should help successful runs

The template system is designed around helping the user make prompts that
closely align with the Agent's architecture. The templates are designed to be
called and have the user replace the placeholders with their own information.
Not much really else to update here, but I wanted to make a note of it. The
templates are stored in text files in the `templates` folder, and they can be
easily modified or added to as needed.

[Code here](https://github.com/dan-damit/TechToolbox/tree/main/AI/Tasks/Templates)

### dan

---

# OpenAI Integration!

**Date:** 2026-7-29 **Tags:** ai, development

## I have integrated OpenAI into the TechToolbox!

Now operators are no longer required to have a local LLM installed, as the
OpenAI API can be used to provide cloud-based LLM inference. This is a great
step forward, as it allows for more flexibility and accessibility for users who
may not have the resources to run a local LLM. The integration is designed to be
seamless, and the user can easily switch between using a local LLM or the OpenAI
API as needed. This opens up new possibilities for the TechToolbox, and I am
excited to see how users will take advantage of this new feature. The
integration is designed to be secure and efficient, and I have taken care to
ensure that user data is protected and that the API calls are optimized for
performance.

The Set-TechAgentApiKey command securely encrypts the api key and stores it in
the module's config.secrets.json. It is encrypted using the Windows Data
Protection API (DPAPI) to ensure that it is secure and cannot be easily accessed
by unauthorized users. The encryption process uses the current user's
credentials to encrypt the api key, so only the user who set the key can decrypt
it; plus, if the secrets file is moved to a different machine, even the same
user cannot decrypt it...it requires the same user on the same machine that
encrypted it. This ensures that the api key is protected and cannot be easily
compromised. Overall, the Set-TechAgentApiKey command is a secure and efficient
way to store the OpenAI API key for the TechToolbox, and it helps to ensure that
user data is protected and that the API calls are optimized for performance.

```powershell
Set-TechAgentApiKey
Set-TechAgentApiKey -ApiKey "your-api-key-here"
```

Then when using the key in the console:

```plaintext
.PARAMETER ApiKeyEncrypted
    Prefers encrypted config-based API key resolution and skips environment
    variable lookup. Use this when you want to force stored secret usage.
```

Now I just have to keep refining the AI Agent code for better quality outputs!

Sneak peek of my next idea for the agent: A sandboxed headless browser for the
Agent to spin up web content!

### dan
