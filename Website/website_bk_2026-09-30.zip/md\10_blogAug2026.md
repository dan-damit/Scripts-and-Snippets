# Added SEARCH-WEB tool

**Date:** 2026-8-7 **Tags:** ai, development

## I have added a new tool to the TechAgent: SEARCH-WEB

The SEARCH-WEB tool allows the TechAgent to perform web searches and retrieve
relevant information from the internet. This is a significant enhancement, as it
enables the agent to access up-to-date information and provide more accurate
responses to user queries. The tool is driven by the Bing Search API, which
provides a reliable and efficient way to access web search results. The
integration of the SEARCH-WEB tool into the TechAgent opens up new possibilities
for users, as they can now leverage the power of web search to enhance their
interactions with the agent.

That combined with the FETCH-TOOL allows the TechAgent to not only search the
web but also fetch specific data from web pages, making it an even more powerful
tool for users - it's secure too, by requiring a whitelist of domains. That way
it doesn't just fetch any data from the web, but only from trusted sources. This
ensures that the data retrieved is reliable and accurate, and it helps to
protect users from potential security risks associated with fetching data from untrusted sources. Overall, the addition of the SEARCH-WEB tool to the TechAgent is a
significant step forward in enhancing the capabilities of the agent, and it
provides users with a powerful tool for accessing information from the web in a
secure and efficient manner.

[Code here](https://github.com/dan-damit/TechToolbox/tree/main/src/TechToolbox.Agent)

### dan

---

# Heuristic decision-making

**Date:** 2026-8-9 **Tags:** ai, development

## I have added heuristic decision-making capabilities to the TechAgent

This one was a bit of a challenge, but I have successfully implemented heuristic
decision-making capabilities into the TechAgent. This enhancement allows the
agent to make more informed decisions based on a set of predefined rules and
heuristics, rather than relying solely on deterministic algorithms. By
incorporating heuristic decision-making, the TechAgent can now evaluate multiple
options and select the most appropriate course of action based on the context of
the situation.

The hardest part was making sure that the local inference engine could handle
the complexity of the decision-making process, while still maintaining a high
level of performance and responsiveness. I had to carefully design the
heuristics and rules to ensure that they were both effective and efficient, and
I also had to implement a robust testing framework to validate the accuracy and
reliability of the decision-making process.

So far the results have been promising, and I am confident that the addition of
heuristic decision-making capabilities to the TechAgent will greatly enhance its
ability to assist users in a wide range of tasks and scenarios. I look forward
to continuing to refine and improve this feature in the future.

[Code here](https://github.com/dan-damit/TechToolbox/blob/main/src/TechToolbox.Agent/Agent/HeuristicScoringEngine.cs)

### dan

---

# Added model routing logic

**Date:** 2026-8-17 **Tags:** ai, development

## I have added model routing logic to the TechAgent

Basically I wanted to introduce model routing to my TechAgent workflow so the
agent can dynamically choose the most suitable model for a given task, improving
its overall performance and efficiency. For general chat and prompts that won't
require much reasoning, qwen3.8:27b is now the default for deep reasoning.
Qwen3.5:9b is used for lightweight tasks including general chat. Next I want to
improve more on the continuity between prompts.

Also, I fully locked my source code for the agent. I put it all behind a private
repo in GitHub and sanitized all of the git history to remove any intellectual
property or sensitive information. This will make all the old links in my blog
break, but I have almost 13,000 lines of code now in the agent C# src, which is
intellectual property at this point.

### dan