# Adding a visitor counter

**Date:** 2026-2-1 **Tags:** php, javascript

## The visitor counter on home

I wanted a visitor counter for a while on the site. I ended up trying by
injecting the counter from a third party site, but that was making the home page
load very slowly, so I left it without one for a few months now. But now that I
have read about using php and javascript to do the same stuff. It was
surprisingly simple to create a php counter that logs the date, time, and IP of
the visitor to the visitors.log file. I have a counter.json that tracks how many
times the page is loaded by a browser, and the visitors.log in a dir that isn't
served to the web. It was surprising simple... the code is below:

```php
<?php
  header("Content-Type: application/json");
  $counterFile = 'counter.json';
  $logFile = '/volume1/web_logs/visitors.log';
  if (!file_exists($counterFile)) {
      file_put_contents($counterFile, json_encode(["visits" => 0]));
  }
  $data = json_decode(file_get_contents($counterFile), true);
  $data["visits"]++;
  file_put_contents($counterFile, json_encode($data));
  $ip = $_SERVER['REMOTE_ADDR'];
  $entry = date("Y-m-d H:i:s") . " - " . $ip . "\n";
  file_put_contents($logFile, $entry, FILE_APPEND);
  echo json_encode($data);
?>
```

Above is the PHP, and below is the little js snippet that consumes the little
PHP snippet, and the html line that anchors it to the page footer:

```html
<div id="visitCount">Loading visit count...</div>
```

```js
<script>
    fetch("counter.php")
      .then((r) => r.json())
      .then((data) => {
        document.getElementById("visitCount").innerText =
          "Total Visits: " + data.visits;
      })
      .catch(() => {
        document.getElementById("visitCount").innerText =
          "Visit counter unavailable";
      });
</script>
```

Next I want to use more PHP for widgets and things to interact with on
the pages to make it more interesting now that I've learned how to have the
backend use a PHP profile in my Synology for the site.

### dan

---

# Completely modular ini pipeline

**Date:** 2026-2-6 **Tags:** powershell, module, scripting

## I pulled every function out of .psm1

I wanted the leanest loader possible, so I modularize it as much as possible. I
think it's way easier to maintain when each function is it's own .ps1 file. I
ended up making the module initialization pipeline super lean; see below:

```powershell
try {
    Initialize-ModulePath
    Initialize-Config
    Initialize-Logging
    Initialize-Interop
    Initialize-Environment
}
catch {
    Write-Error "Module initialization failed: $_"
    throw
}
if ($env:TT_ExportLocalHelper -eq '1') {
    Export-ModuleMember -Function 'Start-PDQDiagLocalSystem'
}
Export-ModuleMember -Function $publicFunctionNames
```

Each Init function lives in a loader folder in the toolbox. That is just my
style I guess. AMAP - As Modular As Possible lol

[Code here](https://github.com/dan-damit/TechToolbox/blob/main/TechToolbox.psm1)

### dan

---

# Adding AI to my toolbox

**Date:** 2026-2-7 **Tags:** powershell, ai, scripting

## This is so cool...

I added a lil local AI minion to help me analyze code. It's just now on v1, so
it needs some refinement and possibly some more specific prompting in the prompt
script, but so far the groundwork is now laid. 

[Test analysis here](https://github.com/dan-damit/TechToolbox/blob/main/CodeAnalysis/Analysis-TechToolbox-2026-02-07_174822.md)

### dan

---

# Upgrading to Quen 2.5 Coder 14B

**Date:** 2026-2-9 **Tags:** ai, local llm, powershell

## Moving from mistral to the Quen model

I was doing to digging on the most in-depth code analysis model I could run with
the 5080 and settled on the Quen 2.5 Coder 14B. It seemed like the best model I
could use without running out of VRAM in the 5080. Ollama makes it super easy to
grab models via PowerShell

```powershell
ollama pull qwen2.5-coder:14b
```

Then it was simple as updating the script to use the new model. 

```powershell
[CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Prompt,

        [string]$Model = 'qwen2.5-coder:14b'
    )
```

The first test was a big upgrade in feedback compared to mistral:

[MD here](https://github.com/dan-damit/TechToolbox/blob/main/CodeAnalysis/Analysis-Set-PageFileSize-Combined-2026-02-08_203709.md)

### dan

---

# Hardening my network's perimeter

**Date:** 2026-2-13 **Tags:** mikrotik, networking, firewall

## Synology Active Insight FTW

Synology's Active Insight opened my eyes to how many hits my server was still
getting from around the world. Failed logins galore. 3-5 hits every 10 minutes.
So naturally, it came time to figure out why. 

Mikrotik is easy to get wrong but is as powerful as Cisco if done correctly. I
was reading and wondering why it was getting hits when I thought I had a Geo-IP
rule at the top of the list essentially banning 19 countries from hitting my
server.

Turns out I had the Chain set incorrectly, well half way incorrectly. Input
Chain protects inputs to the router itself basically, with the context of bots
trying to logon to the router itself from the outside. FORWARD chain is the
magic ticket to stop traffic from hitting the firewall and getting FORWARDED to
my Synology... I kept the input chain and basically cloned the rule and set it
to forward chain and boom, the failures stopped instantly.

Went from 3-5 per 10 minutes to literally 0. Love it!

```bash
 4    ;;; GeoIP Block - China,Russia,Iran,Iraq,North Korea,Syria,Afghanistan,Belarus,Venezuela,Sudan,Pakistan,Bangladesh,Turkey,Brazil,India,Singapore,Hong Kong,Thailand
      chain=forward action=drop dst-address=192.168.88.0/24 src-address-list=MikroTik-GeoIP in-interface-list=WAN log=yes log-prefix="GEO-IP-BLOCK" 
 5    ;;; GeoIP Block - Router Access
      chain=input action=drop src-address-list=MikroTik-GeoIP in-interface-list=WAN
```

Rule 4 there is the one that now drops FORWARDING traffic. The Epiphany moment
was the traffic was coming from WAN and being forwarded to the server.
Previously I thought the input chain covered that but nope. 

### dan

---

# Email Header Analyzer

**Date:** 2026-2-19 **Tags:** powershell, email, security

## No-nonsense analyzer for header authentication verification

I know there are a tons of these available online now, but I wanted my own... So
I created it with PowerShell. I started with a version for TechToolbox, but my
sysadmin loved it, so I made a stand alone version for the team.

[Code here](https://github.com/dan-damit/Scripts-and-Snippets/blob/main/PowerShell/EmailAnalyzer/AnalyzeEmailHeader.GUI.ps1)

It basically finds the DMARC, DKIM, etc info form the header as well as several
other key datapoints that I find helpful with analyzing a phish attempt email.
It makes it easier to add those datapoints into my Purview Purge workflow
scripts, also within TechToolbox

It has 2 modes! CLI and GUI.

### dan
