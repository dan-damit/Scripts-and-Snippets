# Created a custom API

**Date:** 2026-17-2026 **Tags:** scripting, coding, api

## SaaS changes forcing my hand

Our SaaS vendor is changing things up to the point where I needed to get
creative, and I love getting creative!

Wrote a custom API over the last few weeks. Our ERP SaaS is switching to Linux
containers, and they’re also tightening down filesystem access, so our legacy
ERP functions using the System.IO.WriteAllText method to write Bartender labels
isn’t going to be supported after mid June. 

So I created a custom workflow where the label creation workflows on the SaaS
side no longer write any files at all. Instead, the ERP function will gather the
data for the label, ship it as a JSON payload to my API via HTTPS running on our
Bartender server, and my middleware API will write the file for Bartender to
consume. 

My favorite part is that we can scale it to every label we have. Just a minor
adjustment to the label creation functions in our ERP system, and the middleware
will handle the rest. 

Currently as proof of concept as well as getting the “go ahead” from the powers
that be, I only have a test with 1 label out of the dozens and dozens of total
labels we do… and there are some nuances I have to consider as well yet… like
label schemas…but that can come later if I get the “ok” to build this tool out
further.

No code to share on this one. This is proprietary and not open source...

### dan