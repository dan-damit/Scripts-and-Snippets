# Upgrading to RB5009

**Date:** 2026-3-5 **Tags:** mikrotik, networking

## Was maxing out the hEXs

I realized after changing up the way my GeoIP filtering works, that it loads the
address subnets for countries into the firewall's memory. After I hardened it to
be a GeoIP whitelist, the hEXs memory was almost 100% usage... and the CPU was
constantly between 35-50% or so. 

### Enter the RB5009

It has quaduple the memory and something like 100x more storage onboard, makes
easy work of my firewall rules. An added bonus is, my TDS fiber modem connects
to ether1 at 2.5G. I only have a gig connection, but there is room to expand in
the future now.

It only took like an hour to export the stuff I wanted to keep like CAPsMAN
settings, firewall settings, and the task scheduler that keeps the GeoIP lists
up to date. the rest I just built out - like the DHCP and DNS stuff, the IoT
VLAN, and things like that. 

It was plug and play when I got the config setup in the RB5009. Downtime was
literally 15 seconds, and the cAP AC units didn't complain one bit about
swapping controllers.

I love MikroTik - basically poor man's CISCO.

### dan
