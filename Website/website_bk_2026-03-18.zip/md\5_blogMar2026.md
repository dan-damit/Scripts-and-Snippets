# Upgrading to RB5009

**Date:** 2026-3-5 **Tags:** mikrotik, networking

## Was maxing out the hEXs

I realized after changing up the way my GeoIP filtering works, that it loads the
address subnets for countries into the firewall's memory. After I hardened it to
be a GeoIP whitelist, the hEXs memory was almost 100% usage... and the CPU was
constantly between 35-50% or so. 

### Enter the RB5009

It has quaduple the memory and something like 100x more storage onboard, makes
easy work of my firewall rules. An added bonus is, my TDS fiber modem connects
to ether1 at 2.5G. I only have a gig connection, but there is room to expand in
the future now.

It only took like an hour to export the stuff I wanted to keep like CAPsMAN
settings, firewall settings, and the task scheduler that keeps the GeoIP lists
up to date. the rest I just built out - like the DHCP and DNS stuff, the IoT
VLAN, and things like that. 

It was plug and play when I got the config setup in the RB5009. Downtime was
literally 15 seconds, and the cAP AC units didn't complain one bit about
swapping controllers.

I love MikroTik - basically poor man's CISCO.

### dan

---

# NVIDIA driver issues...

**Date:** 2026-3-11 **Tags:** drivers, crashing, bios

## Recent drivers causing chaos

I think the recent driver updates from NVIDIA brought back (unintentionally I
can imagine) the dang black screen driver crashes. BlueScreenView pointed to the
NVIDIA drivers every time. I ended up using the DDU and some BIOS tweaks to turn
off all active power and performance states. All ASPM "features" have been
disabled in the BIOS. I also forced Max Performance Mode for the power mode in
the NVIDIA control panel. I rolled back to the last driver version that didn't
blow up my system:

[Link here to the NVIDIA 591.74 drivers](https://www.nvidia.com/en-us/drivers/)

Did the manual search for past versions and downloaded 591.74 for my 5080.

### dan
