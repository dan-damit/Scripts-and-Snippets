# Adding a visitor counter

**Date:** 2026-2-1 **Tags:** php, javascript

## The visitor counter on home

I wanted a visitor counter for a while on the site. I ended up trying by
injecting the counter from a third party site, but that was making the home page
load very slowly, so I left it without one for a few months now. But now that I
have read about using php and javascript to do the same stuff. It was
surprisingly simple to create a php counter that logs the date, time, and IP of
the visitor to the visitors.log file. I have a counter.json that tracks how many
times the page is loaded by a browser, and the visitors.log in a dir that isn't
served to the web. It was surprising simple... the code is below:

```php
<?php
  header("Content-Type: application/json");
  $counterFile = 'counter.json';
  $logFile = '/volume1/web_logs/visitors.log';
  if (!file_exists($counterFile)) {
      file_put_contents($counterFile, json_encode(["visits" => 0]));
  }
  $data = json_decode(file_get_contents($counterFile), true);
  $data["visits"]++;
  file_put_contents($counterFile, json_encode($data));
  $ip = $_SERVER['REMOTE_ADDR'];
  $entry = date("Y-m-d H:i:s") . " - " . $ip . "\n";
  file_put_contents($logFile, $entry, FILE_APPEND);
  echo json_encode($data);
?>
```

Above is the PHP, and below is the little js snippet that consumes the little
PHP snippet, and the html line that anchors it to the page footer:

```html
<div id="visitCount">Loading visit count...</div>
```

```js
<script>
    fetch("counter.php")
      .then((r) => r.json())
      .then((data) => {
        document.getElementById("visitCount").innerText =
          "Total Visits: " + data.visits;
      })
      .catch(() => {
        document.getElementById("visitCount").innerText =
          "Visit counter unavailable";
      });
</script>
```

Next I want to use more PHP for widgets and things to interact with on
the pages to make it more interesting now that I've learned how to have the
backend use a PHP profile in my Synology for the site.

### dan

---

# Completely modular ini pipeline

**Date:** 2026-2-6 **Tags:** powershell, module, scripting

## I pulled every function out of .psm1

I wanted the leanest loader possible, so I modularize it as much as possible. I
think it's way easier to maintain when each function is it's own .ps1 file. I
ended up making the module initialization pipeline super lean; see below:

```powershell
try {
    Initialize-ModulePath
    Initialize-Config
    Initialize-Logging
    Initialize-Interop
    Initialize-Environment
}
catch {
    Write-Error "Module initialization failed: $_"
    throw
}
if ($env:TT_ExportLocalHelper -eq '1') {
    Export-ModuleMember -Function 'Start-PDQDiagLocalSystem'
}
Export-ModuleMember -Function $publicFunctionNames
```

Each Init function lives in a loader folder in the toolbox. That is just my
style I guess. AMAP - As Modular As Possible lol

[Code here](https://github.com/dan-damit/TechToolbox/blob/main/TechToolbox.psm1)

### dan
